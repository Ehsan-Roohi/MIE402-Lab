from pathlib import Path
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
import numpy as np
from scipy import ndimage
from scipy.special import softmax
from poses import features
root=Path(__file__).parent
# Selected quarter-turn recurrences in the still-moving, newly darkened images.
seeds=[[75.15,75.325,75.475,75.625,75.80,75.975,76.125,76.30,76.475,76.65,76.80,77.0,77.175,77.35,77.525,77.70,77.90,78.075,78.275,78.45],
[68.45,68.875,69.30,69.725,70.175,70.70,71.225,71.75,72.325,72.90,73.625,74.30,75.025,75.925]]
def sequence(x,t,j,side):
 z=features(x,side); pk=seeds[j]; sel=(t>=pk[0])&(t<=pk[-1]); s=np.interp(t[sel],pk,np.arange(len(pk)))%1
 bins=np.arange(48)/48
 ker=np.exp(36*(np.cos(2*np.pi*(s[None,:]-bins[:,None]))-1)); bank=(ker@z[sel])/ker.sum(1)[:,None]
 bank/=np.linalg.norm(bank,axis=1,keepdims=True)
 score=z@bank.T
 # Temporal smoothing before phase unwrapping for the post-switch low-speed part.
 zc=softmax(30*score,axis=1)@np.exp(2j*np.pi*bins)
 sm=ndimage.gaussian_filter1d(zc.real,.65)+1j*ndimage.gaussian_filter1d(zc.imag,.65)
 phi=np.unwrap(np.angle(sm))/(2*np.pi)/4
 return phi,np.abs(sm),score.max(1)
if __name__=='__main__':
 pts=np.load(root/'patches.npy',mmap_mode='r'); t=np.arange(67*40,len(pts))/40; allp={}
 for j in (0,1):
  for side in (-1,0,1):
   phi,w,s=sequence(pts[67*40:,j],t,j,side)
   allp[f'{j}_{side}']=np.array([phi,w,s])
   intervals=[(75,79),(83,89),(93,99),(100,106),(110,115),(115,125),(129,140),(148,156)]
   def stat(a,b):
    sel=(t>=a)&(t<=b); tt=t[sel];pp=phi[sel];return (round(60*np.polyfit(tt,pp,1)[0],2),round(float(np.median(s[sel])),2),round(float(np.median(w[sel])),2))
   print(j,side,[stat(a,b) for a,b in intervals],flush=True)
 np.savez_compressed(root/'signed_pose.npz',t=t,**allp)

