from pathlib import Path
import os,csv,sys
os.environ['OPENBLAS_NUM_THREADS']='1'
import numpy as np, cv2 as cv
from scipy import ndimage,signal
from PIL import Image, ImageDraw,ImageFont
wd=Path(__file__).parent
def prep(fr):
 return np.stack([cv.GaussianBlur(x,(5,5),1.25) for x in fr]).astype('f')
def spectra(fr,ts,verbose=False):
 smooth=prep(fr);fs=1/np.median(np.diff(ts));nf=max(2048,int(fs*100));outs=[]
 for side in (-1,1):
  x=smooth[:,14:44:3,8:31:3] if side<0 else smooth[:,14:44:3,50:73:3]
  x=x.reshape(len(fr),-1);x=signal.detrend(x,axis=0)
  f,s=signal.periodogram(x,fs=fs,window='hann',axis=0,nfft=nf,scaling='spectrum')
  p=s.mean(1);peaks=signal.find_peaks(p)[0];peaks=[v for v in peaks if max(.12,1.32/(ts[-1]-ts[0]))<f[v]<.48*fs]
  if not peaks: outs.append((np.nan,np.nan,0,0,0,np.nan,np.nan,[])); continue
  sel=sorted(peaks,key=lambda n:p[n],reverse=True); h=sel[0]; nu=f[h]
  # Inspect the strongest periodic pixel with good frequency selectivity on this side.
  band=abs(f-nu)<max(.16*nu,1/(ts[-1]-ts[0]));sp=s[band].sum(0)
  weight=sp/(s[(f>.15)&(f<.48*fs)].sum(0)+1e-8)
  pix=np.argmax(sp*weight**2); trace=x[:,pix]
  trend=ndimage.gaussian_filter1d(trace,max(2,fs/nu*.8));zz=trace-trend
  ids=signal.find_peaks(zz,distance=max(1,round(fs/nu*.61)),prominence=max(2,.29*np.ptp(np.percentile(zz,[5,95]))))[0]
  nu2=(len(ids)-1)/(ts[ids[-1]]-ts[ids[0]]) if len(ids)>=2 else np.nan
  outs.append((nu,nu2,len(ids),p[h],float(weight[pix]),ts[ids[0]] if len(ids) else np.nan,ts[ids[-1]] if len(ids) else np.nan,[(round(f[i],2),round(p[i],1)) for i in sel[:4]]))
 return outs
def flow(fr,ts):
 a=prep(fr);ret=[]
 for lag in [1,3,6]:
  mid=(a[lag:]+a[:-lag])*.5; temp=(a[lag:]-a[:-lag]);gy,gx=np.gradient(mid,axis=(1,2))
  div=[]
  for yt,yb in [(14,41),(15,29),(26,40)]:
   val=[]
   for xa,xb in [(9,30),(50,71)]:
    sl=np.s_[:,yt:yb,xa:xb];xx=gx[sl]; yy=gy[sl];tt=temp[sl]
    X=(xx*xx).sum((1,2));Y=(yy*yy).sum((1,2));Z=(xx*yy).sum((1,2));tx=(tt*xx).sum((1,2));ty=(tt*yy).sum((1,2))
    v=(Z*tx-X*ty)/np.maximum(X*Y-Z**2,1e-4)
    val.append(v/(ts[lag:]-ts[:-lag]))
   v=val[1]-val[0];div.append(round(np.mean(np.clip(v,*np.percentile(v,[6,94]))),2))
  ret.append(div)
 return ret
def sheet(items,out):
 xs=12; w,h=120,104;pic=Image.new('RGB',(w*xs,h*len(items)),'white'); dr=ImageDraw.Draw(pic)
 for j,(label,im,t) in enumerate(items):
  for k,idx in enumerate(np.linspace(0,len(t)-1,xs,dtype=int)):
   x=k*w;y=j*h
   dr.text((x+2,y+1),f'{label} {t[idx]:.1f}',fill='black')
   pic.paste(Image.fromarray(im[idx]).resize((115,82)),(x,y+15))
 pic.save(wd/out,quality=89)
if __name__=='__main__':
 if sys.argv[1]=='home':
  items=[]
  for file in sorted(wd.glob('home_patch_*.npz')):
   p=np.load(file);im,t=p['im'],p['t'];nam=file.stem.replace('home_patch_','');items.append((nam[:1]+nam.split('_')[-1],im,t))
   print(nam, 'spectrum',*[str((round(a*15,1),round(b*15,1),npas,round(power,1),round(s,2),tops)) for a,b,npas,power,s,tf,te,tops in spectra(im,t)],'flow',flow(im,t),flush=True)
  sheet(items,'check_home_crops.jpg')
 else:
  p=np.load(wd/'patches.npy',mmap_mode='r');met=np.load(wd/'metrics.npz');items=[]
  aa=[(12,18),(20,25),(38,44),(48,54),(54,59),(69,75),(75,82),(82,90),(92,100),(102,111),(115,125),(132,142),(149,158)]
  for a,b in aa:
   for j in range(3):
    im=p[a*40:b*40,j];t=np.arange(a*40,b*40)/40
    if j<2:items.append((chr(65+j),im,t))
    ospec=spectra(im,t); print(a,b,chr(65+j),[(round(u[0]*15,1),round(u[1]*15,1),u[2],round(u[3],1),round(u[4],2)) for u in ospec], 'flow',np.array(flow(im,t))[:,0], 'reg',round(float(np.median(met['values'][a*40:b*40,j])),2),flush=True)
  sheet(items,'check_lab_crops.jpg')

