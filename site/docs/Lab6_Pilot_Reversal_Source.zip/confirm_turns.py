from pathlib import Path
import os,sys
os.environ['OPENBLAS_NUM_THREADS']='1'
import numpy as np,cv2 as cv
from scipy import ndimage,signal
from poses import features
wd=Path(__file__).parent
cv.setNumThreads(1)
# Each datum is registered directly to the same fixed glass frame to avoid accumulating drift.
def patchset(cam,tm,centre,R,a,b,dec=2):
 cam.set(cv.CAP_PROP_POS_FRAMES,round(tm*40));ok,raw=cam.read();ref=cv.cvtColor(raw,cv.COLOR_BGR2GRAY);cx,cy=centre
 mask=np.zeros_like(ref);cv.ellipse(mask,(cx,cy),(75,94),0,0,360,255,-1);cv.ellipse(mask,(cx,cy),(R+4,25),0,0,360,0,-1)
 pts=cv.goodFeaturesToTrack(ref,120,.004,3,mask=mask)
 cam.set(cv.CAP_PROP_POS_FRAMES,a*40); ims=[];ts=[];qc=[]
 for i in range(a*40,b*40):
  if i%dec:cam.grab();continue
  ok,img=cam.read();gray=cv.cvtColor(img,cv.COLOR_BGR2GRAY)
  cur,st,_=cv.calcOpticalFlowPyrLK(ref,gray,pts,None,winSize=(21,21),maxLevel=3)
  inv,st2,_=cv.calcOpticalFlowPyrLK(gray,ref,cur,None,winSize=(21,21),maxLevel=3)
  good=(st[:,0]>0)&(st2[:,0]>0)&(np.linalg.norm(inv[:,0]-pts[:,0],axis=1)<.9)
  mat,m=cv.estimateAffinePartial2D(pts[good],cur[good],method=cv.RANSAC,ransacReprojThreshold=1.25)
  assert mat is not None,(i,good.sum())
  qc.append(m.sum()); crop=mat.copy();crop[:,2]+=mat[:,:2]@np.array([cx-40,cy-29])
  ims.append(cv.warpAffine(gray,crop,(80,58),flags=cv.WARP_INVERSE_MAP|cv.INTER_LINEAR))
  ts.append(i/40)
 return np.array(ims),np.array(ts),np.array(qc)
def turn(im,t,guess):
 outs=[]
 for side in [1,-1,0]:
  feat=features(im,side)
  vals=[]
  for delta in [1.5,2,2.8]:
   near=np.abs(t-guess)<.3;prev=np.abs(t-(guess-delta))<.23
   v=feat[near].mean(0)-feat[prev].mean(0);v/=np.linalg.norm(v)+1e-7
   z=feat@v
   # Over the turning arc, the pose projection has a local extremum.
   sm=ndimage.gaussian_filter1d(z,4)
   region=np.where(abs(t-guess)<1.7)[0];it=region[np.argmax(sm[region])]
   win=abs(t-t[it])<1.05
   coef=np.polyfit(t[win]-t[it],sm[win],2)
   est=t[it] if abs(coef[0])<1e-8 else t[it]-coef[1]/(2*coef[0])
   vals.append(round(float(est),2))
   if delta==2:outs.append(sm)
  print('side',side,'projected extrema',vals,flush=True)
 return np.array(outs)
if __name__=='__main__':
 cam=cv.VideoCapture(str(wd/'analysis_proxy.mp4'))
 for j,(tm,hub,rad,a,b,guess) in enumerate([(103,(310,350),32,97,111,103.5),(85,(326,451),39,79,94,85.3)]):
  im,t,q=patchset(cam,tm,hub,rad,a,b)
  print('local',j,'fixed landmarks',int(q.min()),int(np.median(q)),flush=True)
  curves=turn(im,t,guess)
  from measure import flow
  for m in range(a+1,b):
   sel=abs(t-m)<.7
   print(m,np.round(np.array(flow(im[sel],t[sel]))[:,0],2).tolist(),end=' / ')
  print(flush=True)
  np.savez_compressed(wd/f'local_turn_{j}.npz',im=im,t=t,q=q,curves=curves)

