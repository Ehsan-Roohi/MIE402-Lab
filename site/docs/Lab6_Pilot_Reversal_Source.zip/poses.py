from pathlib import Path
import os,sys
os.environ['OPENBLAS_NUM_THREADS']='1'
import numpy as np,cv2 as cv
from scipy import ndimage,signal
from PIL import Image, ImageDraw
from measure import prep
wd=Path(__file__).parent
def features(im,side,region='normal'):
 sm=prep(im)
 yy=(slice(12,45,2) if region=='normal' else slice(15,43,2))
 xs={-1:slice(7,35,2),1:slice(46,74,2),0:slice(9,73,2)}[side]
 # Local intensity contrast and edge orientation provide robustness to slowly changing illumination.
 sub=sm[:,yy,xs]
 hi=sub-sub.mean((1,2),keepdims=True)
 hi=hi/(hi.std((1,2),keepdims=True)+6)
 gx=np.gradient(sm,axis=2)[:,yy,xs];gy=np.gradient(sm,axis=1)[:,yy,xs]
 def norm(x,eps):
  a=x.reshape(len(x),-1)
  return a/(np.linalg.norm(a,axis=1,keepdims=True)+eps)
 a=np.concatenate([norm(hi,1),.38*norm(gx,5),.38*norm(gy,5)],axis=1)
 return norm(a,0.001)
def timings(im,t,anchor,tmin,dt,side=0):
 z=features(im,side)
 ref=z[np.argmin(abs(t-anchor))].copy()
 scores=z@ref
 ids=signal.find_peaks(scores,distance=round(dt/np.median(np.diff(t))),prominence=tmin)[0]
 return [(round(t[i],2),round(float(scores[i]),2)) for i in ids]
def home():
 for p in sorted(wd.glob('home_patch_*.npz')):
  a=np.load(p);im,t=a['im'],a['t']; nm=p.stem[11:];print(nm)
  for anchor in [t[0]+1.1,(t[-1]+t[0])*.5,t[-1]-1.5]:
   print(round(anchor,1),[(s,timings(im,t,anchor,.06,1.1,s)) for s in (0,1,-1)])
def lab():
 x=np.load(wd/'patches.npy',mmap_mode='r')
 for j,ref,dt,prom in [(0,(75,83),.12,.12),(1,(68,77),.26,.10)]:
  a,b=ref;im=x[a*40:b*40,j];t=np.arange(len(im))/40+a
  print(chr(65+j),ref)
  for ta in [a+1.3,a+2.6,a+4.2]:
   print(ta,[(s,timings(im,t,ta,prom,dt,s)) for s in (1,0,-1)])
def seq():
 x=np.load(wd/'patches.npy',mmap_mode='r');met=np.load(wd/'metrics.npz')
 from measure import sheet
 for j,(a,b) in enumerate([(97,113),(79,96)]):
  times=np.arange(a,b+.001,.5);out=Image.new('RGB',(8*130,((len(times)+7)//8)*114),'white');dr=ImageDraw.Draw(out)
  for k,t in enumerate(times):
   u=k%8*130;v=k//8*114; im=Image.fromarray(x[round(t*40),j]);out.paste(im.resize((126,87)),(u,v+21));dr.text((u+3,v+2),f'{t:.1f} s',fill='black')
  out.save(wd/f'turn_inspect_{j}.jpg',quality=93)
if __name__=='__main__':
 home();lab();seq()
