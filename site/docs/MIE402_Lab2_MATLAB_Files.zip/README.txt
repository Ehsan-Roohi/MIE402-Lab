MIE 402 Lab 2 analysis files — Fall 2026, corrected October 2026

1. Install PendulumMotionAnalyzer_V4.mltbx in MATLAB.
2. Select Single Pendulum, enter the actual capture frame rate, calibrate,
   locate pivot and bob, run Quick Review, then Analyze All Frames.
3. Save Results to an ExpData MAT file. Retain the raw MP4.
4. Run test_sineFit.m on its synthetic case. Then run
   Run_Lab2_ExpData_Analysis.m; select the ExpData MAT file when prompted.
   Keep sineFit.m beside that script. Never press Run inside sineFit.m itself.
5. The MATLAB script now stops when >10% positions are missing or a gap
   exceeds 0.05 s. Do not use a fit through mostly missing points in a report.
6. The helper uses the mean of the same interpolated vector as its FFT and
   excludes the zero-frequency bin. This prevents a biased DC peak from
   initializing a flat fit on nonuniformly tracked data.

If you do not have MATLAB, the included MIE402_Lab2_Analyze_ExpData.py can
read a v5 MAT file or a ZIP containing it. It needs NumPy and Matplotlib:
python MIE402_Lab2_Analyze_ExpData.py --input your_data.zip --output-dir results
It makes a diagnostic constant-sine and damped-sine comparison and states
whether tracking meets the 90% valid-position threshold. The damped fit is
exploratory, especially when many frames are missing; re-track the video.

A constant-amplitude sine does not follow a visibly decaying envelope.
The frequency may still be useful if measured points are reliable, but the
overlay must be inspected. Report the measured frame coverage and any limits.
