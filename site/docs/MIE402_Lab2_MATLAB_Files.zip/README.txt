MIE 402 — Lab 2 MATLAB Files (Fall 2026)

Files
1. PendulumMotionAnalyzer_V4.mltbx
   MATLAB app installer used to track the pendulum bob in the recorded high-speed video and save ExpData to a MAT file.

2. sineFit.m
   Optional helper used during analysis to estimate offset, amplitude, frequency, and phase of a measured sinusoidal signal. Updated September 2026 to accept either row or column vectors for time and angle.

3. test_sineFit.m
   A short synthetic-data check for the corrected helper. Run it in MATLAB before fitting experimental data.

Install and run the analyzer
1. Open MATLAB.
2. Double-click PendulumMotionAnalyzer_V4.mltbx and choose Install.
3. Open Apps > My Apps > Pendulum Motion Analyzer.
4. Select Single pendulum and enter the ACTUAL recording frame rate.
5. Load the video, calibrate the known distance, mark the pivot and bob, run Quick Review, then Analyze All Frames.
6. Select Save Results. Keep the generated ExpData MAT file and raw video.

Using sineFit.m
Place sineFit.m in the same working folder as your analysis script and MAT files. MATLAB must be able to see it on the current folder or path.

Example (after your analysis script has calculated the angle vector theta):
    t = ExpData(:,1);  % time in seconds
    p = sineFit(t,theta,0);  % 0 skips the optional plots
    fprintf('Fitted frequency: %.4f Hz\n',p(3));

Time must be strictly increasing and in seconds. Both inputs must contain the same number of finite values. The fitted frequency p(3) is in Hz, and p(4) is phase in radians. Do not call sineFit on x- or y-position directly if the aim is pendulum angle; calculate theta first. For large release angles or visibly decaying amplitude, one constant-amplitude sine does not exactly represent the motion. Inspect the overlaid curve and use peak-to-peak periods or an FFT as a cross-check.

Troubleshooting: run `which sineFit -all` to confirm MATLAB uses the new file. Run `test_sineFit` to check the helper on a known signal. If experimental data still fail, retain the full MATLAB error text and the saved ExpData MAT file.

Use V4 from this package. Older course documents may refer to V3.
