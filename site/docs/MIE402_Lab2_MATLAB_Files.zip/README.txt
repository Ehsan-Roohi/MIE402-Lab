MIE 402 — Lab 2 MATLAB Files (Fall 2026)

Files
1. PendulumMotionAnalyzer_V4.mltbx
   MATLAB app installer used to track the pendulum bob in the recorded high-speed video and save ExpData to a MAT file.

2. sineFit.m
   Optional helper used during analysis to estimate offset, amplitude, frequency, and phase of a measured sinusoidal signal.

Install and run the analyzer
1. Open MATLAB.
2. Double-click PendulumMotionAnalyzer_V4.mltbx and choose Install.
3. Open Apps > My Apps > Pendulum Motion Analyzer.
4. Select Single pendulum and enter the ACTUAL recording frame rate.
5. Load the video, calibrate the known distance, mark the pivot and bob, run Quick Review, then Analyze All Frames.
6. Select Save Results. Keep the generated ExpData MAT file and raw video.

Using sineFit.m
Place sineFit.m in the same working folder as your analysis script and MAT files. MATLAB must be able to see it on the current folder or path.

Use V4 from this package. Older course documents may refer to V3.
