MIE 402 Pre-Lab 4 · Fall 2026
Open the supplied notebook in Google Colab. Students do not write code.
Submit ONE Word/PDF on Canvas before your own Lab 4 section: calculations,
predictions, labeled plots, and brief written interpretations.
Source of record: https://github.com/Ehsan-Roohi/MIE402-Lab/blob/main/site/docs/MIE402_PreLab4_Fall2026_Student.ipynb
