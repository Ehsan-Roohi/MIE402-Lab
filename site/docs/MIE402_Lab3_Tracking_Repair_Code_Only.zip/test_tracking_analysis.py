"""Scientific regression checks; run with the same Python requirements."""
import numpy as np
from MIE402_Lab3_Analyze_ExpData import analyze, runs

def coordinates(t,a,b):
    x1=180*np.sin(a);y1=-180*np.cos(a)
    return np.column_stack((t,x1,y1,x1+138*np.sin(b),y1-138*np.cos(b)))

def main():
    t=np.arange(0,4,.002);a=.25*np.cos(2*np.pi*t);b=.35*np.cos(2*np.pi*1.2*t)
    d=coordinates(t,a,b)
    clean=analyze(d)
    assert np.max(abs(clean['continuous'][:,0]-a))<1e-12
    assert np.max(abs(clean['continuous'][:,1]-b))<1e-12
    # A collapsed vector is finite, but must NOT become atan2(0,0) angle data.
    bad=d.copy();bad[300:305,3:5]=bad[300:305,1:3]
    r=analyze(bad)
    assert not np.any(r['observed'][300:305,1])
    assert np.all(r['filled'][300:305,1])
    assert np.max(abs(r['continuous'][:,1]-b))<.001
    # Missing endpoints and a long internal gap: preserve, never extrapolate or bridge.
    bad=d.copy();bad[:2,1:]=np.nan;bad[-3:,1:]=np.nan;bad[500:700,3:]=np.nan
    r=analyze(bad)
    assert np.all(np.isnan(r['continuous'][:2]))
    assert np.all(np.isnan(r['continuous'][-3:]))
    assert np.all(np.isnan(r['continuous'][500:700,1]))
    assert len(runs(np.isfinite(r['continuous'][:,1])))==2
    assert r['spectra'][0]['start_index']==r['spectra'][1]['start_index']
    assert r['spectra'][0]['stop_index']==r['spectra'][1]['stop_index']
    # Genuine two-turn rotation must survive; principal orientation is separate.
    b=4*np.pi*t/t[-1];d=coordinates(t,np.zeros_like(t),b);r=analyze(d)
    assert abs(np.ptp(r['continuous'][:,1])-4*np.pi)<1e-10
    assert np.max(abs(r['principal'][:,1]))<=np.pi+1e-12
    assert r['spectra'][1]['unit']=='1'
    # Do not silently reorder or repair duplicated timestamps.
    d[100,0]=d[99,0]
    try:analyze(d)
    except ValueError:pass
    else:raise AssertionError('Duplicated timestamps were silently accepted')
    print('PASS: clean geometry, duplicate-bob rejection, bounded short-gap repair, missing endpoints, long-gap segmentation, common FFT window, genuine rotations, timestamp validation.')

if __name__=='__main__':main()
