MIE 402 Pre-Lab 1
Submit one Word or PDF file containing all requested calculations, tables, figures, and written responses. No Python coding is required.
