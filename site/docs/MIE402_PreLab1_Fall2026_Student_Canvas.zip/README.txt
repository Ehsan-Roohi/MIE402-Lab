# MIE 402 Pre-Lab 1 — Fall 2026

Open `MIE402_PreLab1_Fall2026_Student.ipynb` in Jupyter Notebook, JupyterLab, or Google Colab.

Required Python packages:

- numpy
- matplotlib

Run all cells, type your responses in the four response sections, keep the figures visible, and export the completed notebook to HTML or PDF for Canvas submission.
